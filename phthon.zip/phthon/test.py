from sys import displayhook
import pandas as pd
import seaborn as sns
import missingno as msno
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib.ticker import ScalarFormatter

df = pd.read_csv('C:/Users/Pay Store/Desktop/japan_birth.csv',index_col=0)



formatter = mpl.ticker.StrMethodFormatter('{x:,.0f}')


def summary(df):
    print(f'data shape: {df.shape}')
    summ = pd.DataFrame(df.dtypes, columns=['Data Type'])
    summ['Missing#'] = df.isna().sum()
    summ['Missing%'] = (df.isna().sum())/len(df)
    summ['Dups'] = df.duplicated().sum()
    summ['Uniques'] = df.nunique().values
    summ['Count'] = df.count().values
    desc = pd.DataFrame(df.describe(include='all').transpose())
    summ['Min'] = desc['min'].values
    summ['Max'] = desc['max'].values
    summ['Average'] = desc['mean'].values
    summ['Standard Deviation'] = desc['std'].values
    summ['First Value'] = df.loc[0].values
    summ['Second Value'] = df.loc[1].values
    summ['Third Value'] = df.loc[2].values

    displayhook(summ)

summary(df)

key_columns = ['year', 'birth_total', 'birth_rate',
       'total_fertility_rate', 'population_total',
       'infant_death_total', 'infant_death_rate',
       'infant_deaths_in_total_deaths',
       'stillbirth_total', 'stillbirth_rate',
       'weeks_under_28', 'weeks_28-31',
       'weeks_32-36', 'weeks_37-41', 'weeks_over_42', 'mother_age_avg',
       'mother_age_under_19', 'mother_age_20-24', 'mother_age_25-29',
       'mother_age_30-34', 'mother_age_35-39', 'mother_age_40-44',
       'mother_age_over_45', 'father_age_avg', 'legitimate_child',
       'illegitimate_child']
key_df = df[key_columns]

msno.matrix(key_df, figsize=(10,6), color=(0,.3,.3))


plt.figure(figsize=(15,10))
sns.heatmap(key_df.corr(),annot=True,cmap='Greens')
plt.show()

ax = df.plot(x="year", y=["birth_total", "infant_death_total", "stillbirth_total"], figsize=(12,5))
ax.yaxis.set_major_formatter(formatter)
plt.show()

df.plot(x="year", y=["birth_gender_ratio", "infant_death_gender_ratio", "stillbirth_gender_ratio"], figsize=(12,5))

ax = df.plot.bar(x="year", y=["birth_male", "birth_female"], figsize=(12,5), stacked=True)
ax.yaxis.set_major_formatter(formatter)
plt.xticks(ticks=range(len(df["year"])), labels=[v if i%3 == 0 else '' for i, v in enumerate(df["year"])])
plt.show()

fig, (ax1, ax2) = plt.subplots(ncols=2)
ax1.barh(df["year"], df["birth_male"], align='center')
ax2.barh(df["year"], df["birth_female"], align='center', color="orange")
ax1.invert_xaxis()
ax1.set_title("Male Birth")
ax2.set_title("Female Birth")
ax1.yaxis.set_ticklabels([])
ax1.xaxis.set_major_formatter(formatter)
ax2.xaxis.set_major_formatter(formatter)
plt.show()

ax = df.plot.bar(x="year", y=["infant_death_male", "infant_death_female"], figsize=(12,5), stacked=True)
ax.yaxis.set_major_formatter(formatter)
plt.xticks(ticks=range(len(df["year"])), labels=[v if i%3 == 0 else '' for i, v in enumerate(df["year"])])
plt.show()

fig, (ax1, ax2) = plt.subplots(ncols=2)
ax1.barh(df["year"], df["infant_death_male"], align='center')
ax2.barh(df["year"], df["infant_death_female"], align='center', color="orange")
ax1.invert_xaxis()
ax1.set_title("Male Infant Death")
ax2.set_title("Female Infant Death")
ax1.yaxis.set_ticklabels([])
ax1.xaxis.set_major_formatter(formatter)
ax2.xaxis.set_major_formatter(formatter)
plt.show()

ax = df.plot.bar(x="year", y=["stillbirth_male", "stillbirth_female"], figsize=(12,5), stacked=True)
ax.yaxis.set_major_formatter(formatter)
plt.xticks(ticks=range(len(df["year"])), labels=[v if i%3 == 0 else '' for i, v in enumerate(df["year"])])
plt.show()

fig, (ax1, ax2) = plt.subplots(ncols=2)
ax1.barh(df["year"], df["stillbirth_male"], align='center')
ax2.barh(df["year"], df["stillbirth_female"], align='center', color="orange")
ax1.invert_xaxis()
ax1.set_title("Male Stillbirth")
ax2.set_title("Female Stillbirth")
ax1.yaxis.set_ticklabels([])
ax1.xaxis.set_major_formatter(formatter)
ax2.xaxis.set_major_formatter(formatter)
plt.show()


df["stillbirth_pct"] = df["stillbirth_total"] / (df["birth_total"] + df["stillbirth_total"]) * 100
df["infant_death_pct"] = df["infant_death_total"] / df["birth_total"] * 100

df["early_terms_pct"] = (df["weeks_under_28"] + df["weeks_28-31"] + df["weeks_32-36"]) / df["birth_total"] * 100
df["full_terms_pct"] = df["weeks_37-41"] / df["birth_total"] * 100
df["late_terms_pct"] = df["weeks_over_42"] / df["birth_total"] * 100

df["legitimate_child_pct"] = df['legitimate_child'] / df["birth_total"] * 100
df["illegitimate_child_pct"] = df['illegitimate_child'] / df["birth_total"] * 100

summary(df[["stillbirth_pct", "infant_death_pct", "early_terms_pct", "full_terms_pct", "late_terms_pct", "legitimate_child_pct", "illegitimate_child_pct"]])


plt.scatter(x=df["stillbirth_pct"], y=df["infant_death_pct"], c=df["year"])
plt.xlabel("Stillbirth %")
plt.ylabel("Infant Death %")
cbar = plt.colorbar()
plt.show()



x = df[df["year"] > 1990]
plt.scatter(x=x["stillbirth_pct"], y=x["infant_death_pct"], c=x["mother_age_avg"])
plt.xlabel("Stillbirth %")
plt.ylabel("Infant Death %")
cbar = plt.colorbar()
cbar.set_label("Mother's Average Age")
plt.title("Statistics After Year 1990")
plt.show()


ax = df[df["full_terms_pct"].notna()].plot.bar(x="year", y=["full_terms_pct", "early_terms_pct", "late_terms_pct"], figsize=(12,5), stacked=True)
ax.set_ylabel("Percentage")
plt.show()


ax = df[df["legitimate_child_pct"].notna()].plot.bar(x="year", y=["legitimate_child_pct", "illegitimate_child_pct"], figsize=(12,5), stacked=True)
ax.set_ylabel("Percentage")
plt.show()


ax = df.plot(x="year", y=["firstborn", "secondborn", "thirdborn", "forthborn", "fifthborn_and_above"], figsize=(12,5), marker='o', markersize=4)
ax.yaxis.set_major_formatter(formatter)
plt.show()


ax = df[df["firstborn"].notna()].plot.bar(x="year", y=["firstborn", "secondborn", "thirdborn", "forthborn", "fifthborn_and_above"], figsize=(12,5), stacked=True)
ax.yaxis.set_major_formatter(formatter)
plt.show()


plt.figure(figsize=(4,2))
sns.heatmap(df[["mother_age_avg", "father_age_avg"]].corr(),annot=True,cmap='Greens')
plt.show()

df.plot(x="year", y=["father_age_avg", "mother_age_avg"], figsize=(12,5), marker='o', markersize=4)
plt.show()


ax = df.plot(x="year", y=["birth_total", "population_total"], figsize=(12,5))
ax.set_yscale("log")
plt.show()